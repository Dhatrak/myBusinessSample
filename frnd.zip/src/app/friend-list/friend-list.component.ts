import { Component, OnInit } from '@angular/core';
import { FriendService } from '../friend.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-friend-list',
  templateUrl: './friend-list.component.html',
  styleUrls: ['./friend-list.component.css']
})
export class FriendListComponent implements OnInit {
  friendList = [];
id;
fri;
  constructor(private friService:FriendService, private router:Router,private route:ActivatedRoute) {}

  ngOnInit() {
  this.friendList = this.friService.getInfo();
  }
  getData(id)
  {
    this.router.navigate(['/friend-details']);
  }

}
