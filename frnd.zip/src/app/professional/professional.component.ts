import { Component, OnInit } from '@angular/core';
import { FriendService } from '../friend.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-professional',
  templateUrl: './professional.component.html',
  styleUrls: ['./professional.component.css']
})
export class ProfessionalComponent implements OnInit {
id;
fri;
  constructor(private friService:FriendService,private route:ActivatedRoute) { }

  ngOnInit() {
    
    this.route.paramMap.subscribe(param =>{
      this.id = parseInt(param.get("id"));
      this.fri = this.friService.getFriend(this.id);
    });

  }

}
