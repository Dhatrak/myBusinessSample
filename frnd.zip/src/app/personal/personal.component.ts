import { Component, OnInit } from '@angular/core';
import { FriendService } from '../friend.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-personal',
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.css']
})
export class PersonalComponent implements OnInit {
id;
fri;
  constructor(private friService:FriendService,private route:ActivatedRoute) { }

  ngOnInit() {
    
    this.route.paramMap.subscribe(param =>{
      this.id = parseInt(param.get("id"));
      this.fri = this.friService.getFriend(this.id);
    })

  }

}
