import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FriendService {

  friendList = [
    {
      id:1,
      name:"Swati Gaikwad",
      email:"swati@gmail.com",
      mobile:"9876543210",
      city:"Nashik",
      profileImg:"assets/images/new11.jpg"
    },

    {
      id:2,
      name:"Gayatri Nikhade",
      email:"gayatri@gmail.com",
      mobile:"9876543210",
      city:"Mumbai",
      profileImg:"assets/images/cc111.jpg"
    },

    {
      id:3,
      name:"Chhaya Dhatrak",
      email:"dhatrak@gmail.com",
      mobile:"9876543210",
      city:"Delhi",
      profileImg:"assets/images/my1.jpg"
    },

    {
      id:4,
      name:"Kavya Gavate",
      email:"gavate@gmail.com",
      mobile:"9876543210",
      city:"Nashik",
      profileImg:"assets/images/my1.jpg"
    },

    {
      id:5,
      name:"Arun Dhatrak",
      email:"dhatrak1@gmail.com",
      mobile:"9876543210",
      city:"Pune",
      profileImg:"assets/images/arun1.jpg"
    }

  ];

  constructor() { }

  getInfo()
  {
    return this.friendList;
  }

  getFriend(id:number)
  {
    return this.friendList[id-1]; 
  }

  friend()
  {
    return this.friendList.length;
  }
}




