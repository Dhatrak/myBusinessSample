import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FriendService } from '../friend.service';
// import { relative } from 'path';

@Component({
  selector: 'app-friend-details',
  templateUrl: './friend-details.component.html',
  styleUrls: ['./friend-details.component.css']
})

export class FriendDetailsComponent implements OnInit {
fri;
id;

constructor(private route:ActivatedRoute, private friService:FriendService,private router:Router) { }

  ngOnInit() {


    this.route.paramMap.subscribe(param =>{
      this.id = parseInt(param.get("id"));
      this.fri = this.friService.getFriend(this.id);
    })
    // var id: number = parseInt(this.route.snapshot.paramMap.get('id'));
    // console.log("id: "+id);

    // this.fri = this.friService.getFriend(id);
  }

  // back()
  // {
  //   if(this.id>1)
  //   this.id--;
  //   this.router.navigate(['/friend-list']);
  // }
personal()
{
  this.router.navigate(['personal',this.id],{relativeTo:this.route});
}
prof()
{
  this.router.navigate(['professional',this.id],{relativeTo:this.route});
}
}
