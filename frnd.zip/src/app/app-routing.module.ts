import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FriendListComponent } from './friend-list/friend-list.component';
import { FriendDetailsComponent } from './friend-details/friend-details.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PersonalComponent } from './personal/personal.component';
import { ProfessionalComponent } from './professional/professional.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'friend-list',component:FriendListComponent},
  {
    path:'friend-details/:id',component:FriendDetailsComponent,
     children: [
    {path:'personal/:id',component:PersonalComponent},
    {path:'professional/:id',component:ProfessionalComponent}
  ]
},

  {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
